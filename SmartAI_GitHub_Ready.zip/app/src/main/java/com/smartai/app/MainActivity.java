package com.smartai.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.speech.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
 TextView chat; EditText input; Button send,mic;
 @Override public void onCreate(Bundle b){
  super.onCreate(b); setContentView(R.layout.activity_main);
  chat=findViewById(R.id.chat); input=findViewById(R.id.input);
  send=findViewById(R.id.send); mic=findViewById(R.id.mic);
  send.setOnClickListener(v->sendMessage());
  mic.setOnClickListener(v->voiceInput());
 }
 void sendMessage(){
  String q=input.getText().toString().trim(); if(q.isEmpty()) return;
  chat.append("\n\nYou: "+q+"\nSmart AI: "+demoReply(q));
  input.setText("");
 }
 String demoReply(String q){
  String x=q.toLowerCase(Locale.ROOT);
  if(x.contains("hello")||x.contains("hi")||x.contains("namaste")) return "Namaste! 👋 Main Smart AI hoon. Batao, kya karna hai?";
  if(x.contains("naam")) return "Mera naam Smart AI hai. 🤖";
  if(x.contains("help")) return "Main chat, voice input aur future mein real AI answers support kar sakta hoon.";
  return "Main abhi demo mode mein hoon. Real AI answers ke liye secure AI backend connect karna hoga.";
 }
 void voiceInput(){
  Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
  i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
  i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");
  try{ startActivityForResult(i,10); }catch(Exception e){ Toast.makeText(this,"Voice input available nahi hai",Toast.LENGTH_SHORT).show(); }
 }
 @Override protected void onActivityResult(int r,int c,Intent d){
  super.onActivityResult(r,c,d);
  if(r==10 && c==RESULT_OK && d!=null){
   ArrayList<String> a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
   if(a!=null&&!a.isEmpty()){ input.setText(a.get(0)); input.setSelection(input.length()); }
  }
 }
}
