# SmartAI

SmartAI is an Android AI-assistant project.

## Project structure

This repository contains the Android project files needed to open and build the app with Android Studio/Gradle.

## Build

1. Open the project in Android Studio.
2. Let Gradle sync and download the required dependencies.
3. Build the debug APK from **Build → Build APK(s)**.

The generated APK is normally found under `app/build/outputs/apk/`.

## Notes

- Do not commit API keys, passwords, signing keys, or `local.properties`.
- The included `.gitignore` excludes common Android/Gradle generated files and secrets.
